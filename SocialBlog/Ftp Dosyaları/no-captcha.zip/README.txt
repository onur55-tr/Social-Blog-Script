Replace the files:

/ views / index / index_session.phtml
/ public / js / login.sign.up.js
/ views / inc / advertising.php
/ public / ajax / sign_up.php

PS: You must perform these actions on all updates