Replace the following files:

1.)  / public / ajax / sign_up.php
2.) / public / js / login.sign.up.js

And signUp.php file goes in / class_ajax_request /